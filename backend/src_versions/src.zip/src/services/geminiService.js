const { GoogleGenerativeAI } = require("@google/generative-ai");
const {
  RecursiveCharacterTextSplitter,
} = require("@langchain/textsplitters");

const { AppError } = require("../utils/appError");
const {
  normalizeText,
} = require("../utils/textExtraction");

// ==================================================
// Gemini
// ==================================================

const genAI = new GoogleGenerativeAI(
  process.env.GEMINI_API_KEY,
);

const MODEL_NAME =
  process.env.GEMINI_MODEL ||
  "gemini-3.1-flash-lite";

const MAX_INPUT_CHARS = Number(
  process.env.MAX_AI_INPUT_CHARS || 22000,
);

const MAX_SECTION_CHARS = Number(
  process.env.MAX_AI_SECTION_CHARS || 9000,
);

const AI_TIMEOUT_MS = Number(
  process.env.AI_TIMEOUT_MS || 30000,
);

// ==================================================
// Timeout
// ==================================================

const withTimeout = async (
  promise,
  timeoutMs,
) => {
  let timeoutHandle;

  const timeoutPromise =
    new Promise((_, reject) => {
      timeoutHandle = setTimeout(
        () =>
          reject(
            new AppError(
              "AI_TIMEOUT",
              "The AI request timed out. Please try again.",
              408,
              undefined,
              true,
            ),
          ),
        timeoutMs,
      );
    });

  try {
    return await Promise.race([
      promise,
      timeoutPromise,
    ]);
  } finally {
    clearTimeout(timeoutHandle);
  }
};

// ==================================================
// JSON parser
// ==================================================

const parseJsonResponse = (
  rawText,
) => {
  const cleanText = String(
    rawText || "",
  )
    .replace(/```json|```/g, "")
    .trim();

  try {
    return JSON.parse(cleanText);
  } catch (err) {
    const match =
      cleanText.match(
        /\{[\s\S]*\}/,
      );

    if (match) {
      try {
        return JSON.parse(
          match[0],
        );
      } catch (nestedError) {
        throw new AppError(
          "AI_RESPONSE_INVALID",
          "The AI response format was invalid. Please retry.",
          502,
          nestedError.message,
          true,
        );
      }
    }

    throw new AppError(
      "AI_RESPONSE_INVALID",
      "The AI response format was invalid. Please retry.",
      502,
      err.message,
      true,
    );
  }
};

// ==================================================
// Resume chunking
// ==================================================

const splitter =
  new RecursiveCharacterTextSplitter({
    chunkSize:
      MAX_SECTION_CHARS,
    chunkOverlap: 300,
  });

const splitIntoChunks = async (
  text,
) => {
  if (
    !text ||
    text.length <=
      MAX_SECTION_CHARS
  ) {
    return [text];
  }

  const chunks =
    await splitter.splitText(
      text,
    );

  return chunks.length
    ? chunks
    : [text];
};

// ==================================================
// Long resume summarization
// ==================================================

const summarizeLongResume = async (
  model,
  text,
) => {
  if (!text) {
    return "";
  }

  if (
    text.length <=
    MAX_INPUT_CHARS
  ) {
    return text;
  }

  const chunks =
    await splitIntoChunks(text);

  const summaries = [];

  for (
    const [
      index,
      chunk,
    ] of chunks.entries()
  ) {
    const chunkPrompt = `
You are preparing reliable ATS analysis input.

Summarize this resume section into concise factual bullets.

Preserve:
- candidate name
- job titles
- employers
- dates
- years of experience
- technologies
- tools
- programming languages
- frameworks
- databases
- cloud platforms
- certifications
- education
- projects
- measurable achievements
- responsibilities
- domain expertise

Do not invent anything.
Do not infer missing information.
Do not remove important technical details.

Section ${index + 1}/${chunks.length}:

${chunk}
`;

    const result =
      await withTimeout(
        model.generateContent(
          chunkPrompt,
        ),
        AI_TIMEOUT_MS,
      );

    const summary =
      result.response
        .text()
        .trim();

    if (summary) {
      summaries.push(
        summary,
      );
    }
  }

  const combined =
    summaries.join("\n\n");

  if (
    combined.length <=
    MAX_INPUT_CHARS
  ) {
    return combined;
  }

  const compressionPrompt = `
Compress the following resume analysis notes into a highly information-dense factual summary suitable for ATS evaluation.

Preserve:
- candidate identity
- employment history
- dates
- job titles
- technologies
- tools
- frameworks
- databases
- cloud platforms
- certifications
- education
- projects
- measurable achievements
- domain expertise

Do not invent information.
Do not remove important technologies or experience.

Return concise structured bullets only.

Resume notes:

${combined}
`;

  const result =
    await withTimeout(
      model.generateContent(
        compressionPrompt,
      ),
      AI_TIMEOUT_MS,
    );

  return result.response
    .text()
    .trim();
};

// ==================================================
// RAG context
// ==================================================

const buildRagContext = (
  ragResults,
) => {
  if (
    !Array.isArray(
      ragResults,
    ) ||
    !ragResults.length
  ) {
    return "";
  }

  return ragResults
    .map((item, index) => {
      const requirement =
        String(
          item?.requirement ||
            "",
        ).trim();

      if (!requirement) {
        return "";
      }

      const status =
        String(
          item?.status ||
            "missing",
        ).trim();

      const evidence =
        Array.isArray(
          item?.evidence,
        )
          ? item.evidence
              .slice(0, 3)
              .map((entry) => {
                const text =
                  String(
                    entry?.text ||
                      "",
                  ).trim();

                if (!text) {
                  return null;
                }

                const distance =
                  typeof entry?.distance ===
                  "number"
                    ? entry.distance.toFixed(
                        3,
                      )
                    : "n/a";

                return `- [distance=${distance}] ${text}`;
              })
              .filter(Boolean)
              .join("\n")
          : "";

      const requiredTerms =
        Array.isArray(
          item?.requiredTerms,
        )
          ? item.requiredTerms.join(
              ", ",
            )
          : "";

      const matchedTerms =
        Array.isArray(
          item?.matchedTerms,
        )
          ? item.matchedTerms.join(
              ", ",
            )
          : "";

      const missingTerms =
        Array.isArray(
          item?.missingTerms,
        )
          ? item.missingTerms.join(
              ", ",
            )
          : "";

      return `
Requirement ${index + 1}:
${requirement}

Deterministic Retrieval Status:
${status}

Required Technical Terms:
${requiredTerms || "None"}

Matched Technical Terms:
${matchedTerms || "None"}

Missing Technical Terms:
${missingTerms || "None"}

Resume Evidence:
${
  evidence ||
  "No matching resume evidence found."
}
`.trim();
    })
    .filter(Boolean)
    .join("\n\n");
};

// ==================================================
// AI error mapping
// ==================================================

const mapAiError = (
  err,
) => {
  const message =
    String(
      err?.message || "",
    ).toLowerCase();

  if (
    err instanceof AppError
  ) {
    return err;
  }

  if (
    message.includes(
      "token",
    ) ||
    message.includes(
      "context",
    ) ||
    message.includes(
      "maximum input",
    )
  ) {
    return new AppError(
      "TOKEN_LIMIT_EXCEEDED",
      "The resume content exceeded model token limits. Please try a shorter resume.",
      413,
      err.message,
      true,
    );
  }

  if (
    message.includes(
      "deadline",
    ) ||
    message.includes(
      "timeout",
    ) ||
    message.includes(
      "timed out",
    )
  ) {
    return new AppError(
      "AI_TIMEOUT",
      "The AI analysis request timed out. Please try again.",
      408,
      err.message,
      true,
    );
  }

  if (
    message.includes(
      "429",
    ) ||
    message.includes(
      "quota",
    ) ||
    message.includes(
      "rate",
    )
  ) {
    return new AppError(
      "AI_RATE_LIMITED",
      "The AI service is busy right now. Please retry in a moment.",
      429,
      err.message,
      true,
    );
  }

  return new AppError(
    "AI_ANALYSIS_FAILED",
    "The AI service could not complete resume analysis.",
    502,
    err.message,
    true,
  );
};

// ==================================================
// Analyze Resume
// ==================================================

const analyzeResume = async (
  resumeText,
  targetRole = "",
  relevantJDChunks = [],
) => {
  if (
    !resumeText ||
    !resumeText.trim()
  ) {
    throw new AppError(
      "AI_RESUME_EMPTY",
      "Resume text is required for AI analysis.",
      422,
    );
  }

  const model =
    genAI.getGenerativeModel({
      model: MODEL_NAME,
    });

  const normalized =
    normalizeText(
      resumeText,
    );

  const currentDate =
    new Date()
      .toISOString()
      .split("T")[0];

  const hasRagAnalysis =
    Array.isArray(
      relevantJDChunks,
    ) &&
    relevantJDChunks.length >
      0;

  const ragContext =
    buildRagContext(
      relevantJDChunks,
    );

  try {
    const preparedResume =
      await summarizeLongResume(
        model,
        normalized,
      );

    const prompt = `
You are a senior recruiter and ATS optimization expert.

Evaluate resumes for any profession, industry, and seniority.

Your analysis must be:
- factual
- objective
- evidence-based
- role-aware
- ATS-aware
- free from assumptions

Return ONLY a valid JSON object.
Do not return markdown.
Do not return comments.
Do not return explanations outside the JSON object.

========================================
RESUME
========================================

${preparedResume.slice(
  0,
  MAX_INPUT_CHARS,
)}

========================================
TARGET ROLE
========================================

${targetRole || "Not provided"}

========================================
CURRENT DATE
========================================

${currentDate}

========================================
DETERMINISTIC JD MATCHING DATA
========================================

${
  hasRagAnalysis
    ? ragContext
    : "No job description analysis was provided."
}

========================================
CRITICAL MATCHING RULE — RAG IS SOURCE OF TRUTH
========================================

The "DETERMINISTIC JD MATCHING DATA" section contains the complete,
individual job requirements extracted and evaluated by the RAG system.

You MUST use those individual "Requirement N:" entries as the ONLY
source for:

- matchedRequirements
- missingRequirements
- jdMatchScore

DO NOT extract requirements again from the resume.
DO NOT extract requirements again from the raw job description.
DO NOT use the raw job description as a fallback.
DO NOT put the entire job description into matchedRequirements
or missingRequirements.
DO NOT combine multiple requirements into one string.

Each item in matchedRequirements or missingRequirements MUST correspond
to exactly ONE "Requirement N:" from the deterministic RAG data.

Mapping rules:

- strong_match → matchedRequirements
- possible_match → missingRequirements
- missing → missingRequirements

For every Requirement N:

1. Copy the individual requirement text from the "Requirement N:" field.
2. Look only at its deterministic retrieval status and supplied evidence.
3. Put that individual requirement into the appropriate output array.
4. Never replace it with the full job description.

Example:

If the deterministic data contains:

Requirement 1:
Node.js

Deterministic Retrieval Status:
strong_match

Requirement 2:
Express.js

Deterministic Retrieval Status:
missing

Requirement 3:
PostgreSQL

Deterministic Retrieval Status:
missing

Then the output MUST contain:

"matchedRequirements": [
  "Node.js"
],

"missingRequirements": [
  "Express.js",
  "PostgreSQL"
]

It is INVALID to return:

"missingRequirements": [
  "<entire job description>"
]

The raw job description is contextual information only. It is NOT
a source for constructing these arrays.

========================================
TECHNICAL TERM RULE
========================================

Explicit technical evidence is required for technical requirements.

Examples:

"Node.js" requires explicit Node.js/NodeJS evidence.

"Express.js and REST API" requires evidence for both concepts.

"PostgreSQL or another relational database" is satisfied if at least one accepted relational database is explicitly demonstrated.

"Authentication and API security" requires explicit evidence for both authentication and API security.

"Automated backend testing" may be satisfied by explicit automated testing, unit testing, or integration testing evidence.

Do not infer a missing technology from related technologies.

For example:

AWS + Docker + Kubernetes

does NOT prove:

Node.js
Express.js
PostgreSQL
Microservices
API security

========================================
JSON SCHEMA
========================================

{
  "score": <number 1-10 with one decimal>,
  "atsRating": "<Excellent | Good | Fair | Poor>",
  "summary": "<2-3 sentence assessment>",
  "strengths": [
    "<strength 1>",
    "<strength 2>",
    "<strength 3>"
  ],
  "improvements": [
    "<improvement 1>",
    "<improvement 2>",
    "<improvement 3>"
  ],
  "missingKeywords": [
    "<keyword1>",
    "<keyword2>",
    "<keyword3>",
    "<keyword4>",
    "<keyword5>"
  ],
  "jdMatchScore": <number 0-100 or null>,
  "matchedRequirements": [
    "<requirement 1>",
    "<requirement 2>"
  ],
  "missingRequirements": [
    "<requirement 1>",
    "<requirement 2>"
  ],
  "candidateName": "<full name if present, otherwise empty string>",
  "alignment": {
    "matches": <true | false>,
    "confidence": <number 0.0-1.0>
  },
  "recommendedRoles": [
    "<role1>",
    "<role2>",
    "<role3>"
  ],
  "confidenceLevel": <number 0.0-1.0>,
  "recruiterApproval": <number 0-100>
}

========================================
JD ANALYSIS RULES
========================================

If deterministic JD requirements are provided:

- Calculate jdMatchScore from 0 to 100.
- Use deterministic retrieval statuses as the primary evidence.
- matchedRequirements may contain only demonstrated requirements.
- missingRequirements must contain requirements not demonstrated.
- possible_match requirements must not be treated as certain.
- Do not invent requirements.
- Do not invent resume evidence.

If no JD requirements are provided:

- jdMatchScore = null
- matchedRequirements = []
- missingRequirements = []

========================================
GENERAL ANALYSIS RULES
========================================

Analyze ONLY information present in the resume.

Never invent:
- skills
- certifications
- experience
- projects
- technologies
- employers
- job titles
- achievements

Never assume experience from the target role.

Recommendations must be supported by resume evidence.

========================================
DATE RULES
========================================

Use Current Date when interpreting dates.

Treat:
- Present
- Current
- ongoing

as continuing through Current Date.

Calculate experience only from explicitly provided dates.

Do not assume missing dates.

Do not treat future dates as completed experience.

========================================
MISSING KEYWORDS
========================================

Maximum 5.

Only suggest keywords relevant to:
- target role
- candidate profession

Do not include technologies already present in the resume.

Do not recommend unsupported technologies as if the candidate already knows them.

========================================
RECOMMENDED ROLES
========================================

Return exactly 3 realistic job titles.

They must match demonstrated experience.

Do not recommend unrelated roles.

========================================
SCORING
========================================

10.0 = Outstanding
9.0-9.9 = Excellent
8.0-8.9 = Strong
7.0-7.9 = Good
6.0-6.9 = Average
Below 6.0 = Needs significant improvement

Score based on:
- ATS compatibility
- recruiter appeal
- target-role relevance
- clarity
- measurable impact
- technical depth
- structure
- demonstrated experience

========================================
IMPROVEMENTS
========================================

Focus on high-impact improvements.

Do not repeat strengths.

Do not recommend adding experience the candidate does not have.

Do not claim that the candidate should add a technology as existing experience.

========================================
ROLE ALIGNMENT
========================================

If a target role is provided:

Evaluate alignment using demonstrated skills, projects, and experience.

If no target role is provided:

alignment.matches = false
alignment.confidence = 0

========================================
FINAL OUTPUT
========================================

Return ONLY valid JSON.
`;

    const result =
      await withTimeout(
        model.generateContent(
          prompt,
        ),
        AI_TIMEOUT_MS,
      );

    const parsed =
      parseJsonResponse(
        result.response.text(),
      );

    /*
     * Final defensive normalization.
     */

    const normalizedResult = {
      ...parsed,

      confidenceLevel:
        typeof parsed.confidenceLevel ===
        "number"
          ? Number(
              Math.min(
                1,
                Math.max(
                  0,
                  parsed.confidenceLevel,
                ),
              ).toFixed(2),
            )
          : Number(
              Math.min(
                1,
                Math.max(
                  0.3,
                  (Number(
                    parsed.score,
                  ) || 6) / 10,
                ),
              ).toFixed(2),
            ),

      recruiterApproval:
        typeof parsed.recruiterApproval ===
        "number"
          ? Math.round(
              Math.min(
                100,
                Math.max(
                  0,
                  parsed.recruiterApproval,
                ),
              ),
            )
          : Math.round(
              Math.min(
                98,
                Math.max(
                  25,
                  (Number(
                    parsed.score,
                  ) || 6) * 10,
                ),
              ),
            ),
    };

    /*
     * Defensive RAG correction.
     *
     * Even if the model accidentally violates the prompt,
     * deterministic statuses remain authoritative.
     */

    if (hasRagAnalysis) {
      const strongMatches =
        relevantJDChunks
          .filter(
            (item) =>
              item?.status ===
              "strong_match",
          )
          .map(
            (item) =>
              item.requirement,
          );

      const missing =
        relevantJDChunks
          .filter(
            (item) =>
              item?.status ===
                "missing" ||
              item?.status ===
                "possible_match",
          )
          .map(
            (item) =>
              item.requirement,
          );

      normalizedResult.matchedRequirements =
        strongMatches;

      normalizedResult.missingRequirements =
        missing;

      const total =
        relevantJDChunks.length;

      const matched =
        strongMatches.length;

      normalizedResult.jdMatchScore =
        total > 0
          ? Number(
              (
                (matched /
                  total) *
                100
              ).toFixed(1),
            )
          : 0;
    } else {
      normalizedResult.jdMatchScore =
        null;

      normalizedResult.matchedRequirements =
        [];

      normalizedResult.missingRequirements =
        [];
    }

    return normalizedResult;
  } catch (err) {
    throw mapAiError(err);
  }
};

module.exports = {
  analyzeResume,
  buildRagContext,
};
